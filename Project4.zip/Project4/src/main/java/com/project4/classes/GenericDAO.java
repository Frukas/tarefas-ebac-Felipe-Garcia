package com.project4.classes;

public class GenericDAO {

}
