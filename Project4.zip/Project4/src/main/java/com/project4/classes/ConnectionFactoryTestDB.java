package com.project4.classes;

import java.sql.Connection;

import com.project4.interfaces.IConnectionFactory;

public class ConnectionFactoryTestDB implements IConnectionFactory {

	public Connection getDBConnection() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public void closeConnection() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
